#!/usr/bin/python
from glob import glob
from os import path, makedirs
from shutil import copyfile
from xbmcaddon import Addon
from xbmc import sleep, translatePath, executebuiltin
from xbmcgui import Dialog 

def copytree(source, target):
	files = glob(path.join(source,"*"))
	for f in files:
		copyfile(f,path.join(target, path.basename(f)))

addonID = "service.skinshortcuts.update"
MyAddon = Addon(addonID)
AddonName = MyAddon.getAddonInfo("name")
AddonVer = MyAddon.getAddonInfo("version")

source = translatePath(path.join('special://home','addons',addonID,'resources','skinshortcuts')); 
target = translatePath(path.join('special://userdata','addon_data','script.skinshortcuts')); 
lastUpdateFile = path.join(target, AddonVer+'.txt')

if not path.isfile(lastUpdateFile):
	if not path.exists(target):
		makedirs(target)
	# Copy new files
	copytree(source, target)

	f = open(lastUpdateFile, 'w')
	f.write(".")
	f.close()
	xbmc.executebuiltin('StopPVRManager')
	sleep(2000) 
	executebuiltin("xbmc.ReloadSkin()")

lastUpdateFile = path.join(target, 'adult.txt')
if not path.isfile(lastUpdateFile):
	if not path.exists(target):
		makedirs(target)

	sleep(20000) 
	dialog = Dialog()
	i = dialog.yesno("Adult content allow","Do you want to allow adult content?")

	if i == 0:
		xbmc.executebuiltin('Skin.SetString(Custom4HomeItem.Disable,True)')
	else:
		xbmc.executebuiltin('Skin.SetString(Custom4HomeItem.Disable,)')
	f = open(lastUpdateFile, 'w')
	f.write(".")
	f.close()
	sleep(500) 
	executebuiltin("xbmc.ReloadSkin()")
